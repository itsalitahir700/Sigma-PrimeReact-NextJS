# primereact-nextjs-quickstart
Quickstart Application Template for PrimeReact with Nextjs

## Project setup
```
npm install
```

### Compiles and hot-reloads for development
```
npm run dev
```

### Compiles and minifies for production
```
npm run build
```

### Customize configuration
See [Configuration Reference](https://nextjs.org/docs#how-to-use).
