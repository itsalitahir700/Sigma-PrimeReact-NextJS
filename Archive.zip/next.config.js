module.exports = {
    swcMinify: true,
};
